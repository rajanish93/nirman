<?php 


// Silence is golden.